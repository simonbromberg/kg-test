import XCTest
@testable import KGMail

class EmailUtilitiesTests: XCTestCase {

    // UNIT TESTING QUESTION
    //
    // This implementation is incomplete.
    // Write unit tests to test the functionality of EmailUtilities.combineAndSortEmails

}
